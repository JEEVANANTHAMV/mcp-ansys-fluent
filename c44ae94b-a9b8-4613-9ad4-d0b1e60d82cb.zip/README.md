# Ansys Fluent (CFD) MCP

Per-product offline MCP server. See SKILL.md for usage.

* pip client: ansys-fluent-core
* top-level import: ansys.fluent.core
* kind: grpc
* env: ANSYS_ROOT
